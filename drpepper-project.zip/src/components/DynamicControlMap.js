'use client';

import { useEffect, useState } from 'react';
import { Box, Typography, Chip, FormControl, InputLabel, Select, MenuItem, FormControlLabel, Switch } from '@mui/material';
import { Flight, Build, CheckCircle, Warning, TrendingUp, Psychology, FlightTakeoff, FlightLand, Engineering, Security, Speed, Assessment } from '@mui/icons-material';
import dynamic from 'next/dynamic';
import React from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Dynamic imports for Leaflet (only on client side)
const MapContainer = dynamic(() => import('react-leaflet').then(mod => mod.MapContainer), { ssr: false });
const TileLayer = dynamic(() => import('react-leaflet').then(mod => mod.TileLayer), { ssr: false });
const Marker = dynamic(() => import('react-leaflet').then(mod => mod.Marker), { ssr: false });
const Popup = dynamic(() => import('react-leaflet').then(mod => mod.Popup), { ssr: false });
const Polyline = dynamic(() => import('react-leaflet').then(mod => mod.Polyline), { ssr: false });
const Circle = dynamic(() => import('react-leaflet').then(mod => mod.Circle), { ssr: false });

// Airbus aircraft fleet data
const aircraft = [
  { id: 'A001', registration: 'F-WZNW', type: 'A350-900', lat: 43.6298, lng: 1.3638, status: 'active', health: 94, location: 'Toulouse', flightHours: 2450 },
  { id: 'A002', registration: 'F-GKLM', type: 'A320neo', lat: 48.8566, lng: 2.3522, status: 'maintenance', health: 87, location: 'Paris', flightHours: 1890 },
  { id: 'A003', registration: 'F-HPJE', type: 'A380-800', lat: 51.5074, lng: -0.1278, status: 'active', health: 96, location: 'London', flightHours: 3200 },
  { id: 'A004', registration: 'F-WWYB', type: 'A330-300', lat: 40.7128, lng: -74.0060, status: 'maintenance', health: 82, location: 'New York', flightHours: 2780 },
  { id: 'A005', registration: 'F-GXYZ', type: 'A350-1000', lat: 52.5200, lng: 13.4050, status: 'active', health: 91, location: 'Berlin', flightHours: 1560 },
  { id: 'A006', registration: 'F-HABC', type: 'A320ceo', lat: 41.9028, lng: 12.4964, status: 'grounded', health: 45, location: 'Rome', flightHours: 4200 },
  { id: 'A007', registration: 'F-WDEF', type: 'A330-900', lat: 55.7558, lng: 37.6176, status: 'active', health: 89, location: 'Moscow', flightHours: 2100 },
  { id: 'A008', registration: 'F-GHIJ', type: 'A350-900', lat: 35.6762, lng: 139.6503, status: 'active', health: 93, location: 'Tokyo', flightHours: 1980 },
  { id: 'A009', registration: 'F-WKLM', type: 'A380-800', lat: -33.8688, lng: 151.2093, status: 'active', health: 95, location: 'Sydney', flightHours: 2900 },
  { id: 'A010', registration: 'F-HNOP', type: 'A320neo', lat: -23.5505, lng: -46.6333, status: 'maintenance', health: 78, location: 'São Paulo', flightHours: 1650 },
  { id: 'A011', registration: 'F-WQRS', type: 'A350-1000', lat: 25.2048, lng: 55.2708, status: 'active', health: 92, location: 'Dubai', flightHours: 1820 },
  { id: 'A012', registration: 'F-GTUV', type: 'A330-300', lat: 39.9042, lng: 116.4074, status: 'active', health: 88, location: 'Beijing', flightHours: 2340 },
  { id: 'A013', registration: 'F-WXYZ', type: 'A320ceo', lat: 28.6139, lng: 77.2090, status: 'grounded', health: 52, location: 'New Delhi', flightHours: 3800 },
  { id: 'A014', registration: 'F-H123', type: 'A350-900', lat: -26.2041, lng: 28.0473, status: 'active', health: 90, location: 'Johannesburg', flightHours: 1760 },
  { id: 'A015', registration: 'F-W456', type: 'A380-800', lat: 37.7749, lng: -122.4194, status: 'active', health: 94, location: 'San Francisco', flightHours: 2680 }
];

const maintenanceFacilities = [
  { id: 'MF001', name: 'Toulouse Maintenance Hub', lat: 43.6298, lng: 1.3638, capacity: 25, utilization: 78, status: 'operational', type: 'major' },
  { id: 'MF002', name: 'Hamburg Maintenance Center', lat: 53.5511, lng: 9.9937, capacity: 18, utilization: 82, status: 'operational', type: 'major' },
  { id: 'MF003', name: 'Tianjin Maintenance Facility', lat: 39.0842, lng: 117.2009, capacity: 12, utilization: 65, status: 'operational', type: 'regional' },
  { id: 'MF004', name: 'Mobile Maintenance Station', lat: 30.6954, lng: -88.0399, capacity: 8, utilization: 71, status: 'operational', type: 'regional' },
  { id: 'MF005', name: 'Seattle Maintenance Hub', lat: 47.6062, lng: -122.3321, capacity: 15, utilization: 89, status: 'high_demand', type: 'major' },
  { id: 'MF006', name: 'Dubai Maintenance Center', lat: 25.2048, lng: 55.2708, capacity: 20, utilization: 75, status: 'operational', type: 'major' },
  { id: 'MF007', name: 'Singapore Maintenance Hub', lat: 1.3521, lng: 103.8198, capacity: 22, utilization: 93, status: 'critical', type: 'major' },
  { id: 'MF008', name: 'São Paulo Maintenance', lat: -23.5505, lng: -46.6333, capacity: 10, utilization: 87, status: 'high_demand', type: 'regional' }
];

const airports = [
  // Major International Airports
  { id: 'AP001', name: 'Charles de Gaulle Airport', lat: 49.0097, lng: 2.5479, traffic: 'high', type: 'international' },
  { id: 'AP002', name: 'Heathrow Airport', lat: 51.4700, lng: -0.4543, traffic: 'high', type: 'international' },
  { id: 'AP003', name: 'JFK International Airport', lat: 40.6413, lng: -73.7781, traffic: 'high', type: 'international' },
  { id: 'AP004', name: 'Dubai International Airport', lat: 25.2532, lng: 55.3657, traffic: 'high', type: 'international' },
  { id: 'AP005', name: 'Singapore Changi Airport', lat: 1.3644, lng: 103.9915, traffic: 'high', type: 'international' },
  { id: 'AP006', name: 'Tokyo Haneda Airport', lat: 35.5494, lng: 139.7798, traffic: 'high', type: 'international' },
  { id: 'AP007', name: 'Sydney Airport', lat: -33.9399, lng: 151.1753, traffic: 'medium', type: 'international' },
  { id: 'AP008', name: 'São Paulo Guarulhos Airport', lat: -23.4356, lng: -46.4731, traffic: 'medium', type: 'international' },
  { id: 'AP009', name: 'Beijing Capital Airport', lat: 40.0799, lng: 116.6031, traffic: 'high', type: 'international' },
  { id: 'AP010', name: 'Moscow Sheremetyevo Airport', lat: 55.9726, lng: 37.4146, traffic: 'medium', type: 'international' }
];

// Flight routes (aircraft to airports)
const flightRoutes = [
  { from: 'A001', to: 'AP001', status: 'active', duration: '1h 15m' },
  { from: 'A002', to: 'AP002', status: 'scheduled', duration: '1h 30m' },
  { from: 'A003', to: 'AP003', status: 'active', duration: '7h 45m' },
  { from: 'A004', to: 'AP004', status: 'maintenance', duration: 'N/A' },
  { from: 'A005', to: 'AP005', status: 'active', duration: '11h 20m' },
  { from: 'A006', to: 'AP006', status: 'grounded', duration: 'N/A' }
];

// Maintenance zones and operational areas
const zones = [
  // European Operations Hub
  {
    id: 'EZ001',
    name: 'European Operations Hub',
    lat: 48.8566,
    lng: 2.3522,
    radius: 300000, // 300km radius
    aircraftCount: 45,
    maintenanceFacilities: 3,
    avgHealth: 92.5,
    operationalEfficiency: 94.2,
    keyMetrics: { activeAircraft: 42, maintenanceInProgress: 2, groundedAircraft: 1 },
    maintenanceOpportunity: 'high_efficiency',
    keyInsights: 'Strong maintenance infrastructure, high operational efficiency'
  },
  {
    id: 'EZ002',
    name: 'North American Operations',
    lat: 40.7128,
    lng: -74.0060,
    radius: 400000,
    aircraftCount: 38,
    maintenanceFacilities: 2,
    avgHealth: 89.8,
    operationalEfficiency: 91.5,
    keyMetrics: { activeAircraft: 35, maintenanceInProgress: 2, groundedAircraft: 1 },
    maintenanceOpportunity: 'growing_market',
    keyInsights: 'Growing market, expanding maintenance capabilities'
  },
  {
    id: 'EZ003',
    name: 'Asia-Pacific Operations',
    lat: 35.6762,
    lng: 139.6503,
    radius: 350000,
    aircraftCount: 32,
    maintenanceFacilities: 2,
    avgHealth: 91.2,
    operationalEfficiency: 93.8,
    keyMetrics: { activeAircraft: 30, maintenanceInProgress: 1, groundedAircraft: 1 },
    maintenanceOpportunity: 'strategic_growth',
    keyInsights: 'Strategic growth region, high aircraft utilization'
  },
  {
    id: 'EZ004',
    name: 'Middle East Operations',
    lat: 25.2048,
    lng: 55.2708,
    radius: 250000,
    aircraftCount: 28,
    maintenanceFacilities: 1,
    avgHealth: 93.1,
    operationalEfficiency: 95.2,
    keyMetrics: { activeAircraft: 27, maintenanceInProgress: 1, groundedAircraft: 0 },
    maintenanceOpportunity: 'premium_service',
    keyInsights: 'Premium service market, excellent maintenance standards'
  },
  {
    id: 'EZ005',
    name: 'South American Operations',
    lat: -23.5505,
    lng: -46.6333,
    radius: 300000,
    aircraftCount: 18,
    maintenanceFacilities: 1,
    avgHealth: 87.5,
    operationalEfficiency: 89.1,
    keyMetrics: { activeAircraft: 16, maintenanceInProgress: 1, groundedAircraft: 1 },
    maintenanceOpportunity: 'development_region',
    keyInsights: 'Development region, improving maintenance infrastructure'
  }
];

export default function DynamicControlMap({ selectedRegion, onRegionSelect }) {
  const [map, setMap] = useState(null);
  const [mapKey, setMapKey] = useState(0);
  const [showAircraft, setShowAircraft] = useState(true);
  const [showFacilities, setShowFacilities] = useState(true);
  const [showAirports, setShowAirports] = useState(false);
  const [showRoutes, setShowRoutes] = useState(true);
  const [showZones, setShowZones] = useState(true);
  const [selectedAircraftType, setSelectedAircraftType] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');

  useEffect(() => {
    if (map) {
      map.invalidateSize();
    }
  }, [map]);

  // Cleanup map on unmount
  useEffect(() => {
    return () => {
      if (map) {
        map.remove();
      }
    };
  }, [map]);

  // Reset map when filters change significantly
  useEffect(() => {
    setMapKey(prev => prev + 1);
  }, [selectedAircraftType, selectedStatus]);

  // Filter aircraft based on selection
  const filteredAircraft = aircraft.filter(ac => {
    const typeMatch = selectedAircraftType === 'all' || ac.type.includes(selectedAircraftType);
    const statusMatch = selectedStatus === 'all' || ac.status === selectedStatus;
    return typeMatch && statusMatch;
  });

  // Filter facilities based on selection
  const filteredFacilities = maintenanceFacilities.filter(facility => {
    if (selectedAircraftType === 'all') return true;
    // Filter based on facility type and aircraft type compatibility
    return true; // For now, show all facilities
  });

  const getHealthColor = (health) => {
    if (health >= 90) return '#4caf50';
    if (health >= 80) return '#ff9800';
    if (health >= 70) return '#f57c00';
    return '#f44336';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return '#4caf50';
      case 'maintenance': return '#ff9800';
      case 'grounded': return '#f44336';
      case 'scheduled': return '#2196f3';
      default: return '#9e9e9e';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active': return <FlightTakeoff />;
      case 'maintenance': return <Build />;
      case 'grounded': return <FlightLand />;
      case 'scheduled': return <Speed />;
      default: return <Flight />;
    }
  };

  const getFacilityColor = (status) => {
    switch (status) {
      case 'operational': return '#4caf50';
      case 'high_demand': return '#ff9800';
      case 'critical': return '#f44336';
      default: return '#9e9e9e';
    }
  };

  const getFacilitySize = (type) => {
    switch (type) {
      case 'major': return 12;
      case 'regional': return 8;
      default: return 6;
    }
  };

  const getZoneColor = (efficiency) => {
    if (efficiency >= 95) return '#4caf50';
    if (efficiency >= 90) return '#8bc34a';
    if (efficiency >= 85) return '#ff9800';
    if (efficiency >= 80) return '#f57c00';
    return '#f44336';
  };

  const getZoneOpacity = (efficiency) => {
    return Math.max(0.1, Math.min(0.4, efficiency / 100));
  };

  const getZoneRadius = (efficiency) => {
    return Math.max(50000, Math.min(200000, efficiency * 2000));
  };

  const getAircraftIcon = (aircraft) => {
    const getColor = () => {
      return getHealthColor(aircraft.health);
    };

    const getIcon = () => {
      switch (aircraft.type) {
        case 'A380-800': return '🛩️';
        case 'A350-1000': return '✈️';
        case 'A350-900': return '✈️';
        case 'A330-900': return '✈️';
        case 'A330-300': return '✈️';
        case 'A320neo': return '🛩️';
        case 'A320ceo': return '🛩️';
        default: return '✈️';
      }
    };

    return `
      <div
        style="
          width: 24px;
          height: 24px;
          background-color: ${getColor()};
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 12px;
          font-weight: bold;
          border: 2px solid white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.3);
          cursor: pointer;
        "
      >
        ${getIcon()}
      </div>
    `;
  };

  const getFacilityIcon = (facility) => {
    const getColor = () => {
      return getFacilityColor(facility.status);
    };

          return `
      <div
        style="
          width: ${getFacilitySize(facility.type)}px;
          height: ${getFacilitySize(facility.type)}px;
          background-color: ${getColor()};
          border-radius: 50%;
          border: 2px solid white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.3);
          cursor: pointer;
        "
      ></div>
    `;
  };

  const getFlightRoutePaths = () => {
    return flightRoutes
      .filter(route => route.status === 'active')
      .map(route => {
        const aircraftData = aircraft.find(a => a.id === route.from);
        const airportData = airports.find(ap => ap.id === route.to);
        
        if (!aircraftData || !airportData) return null;
        
        return {
          id: route.from,
          path: [
            [aircraftData.lat, aircraftData.lng],
            [airportData.lat, airportData.lng]
          ],
          color: '#2196f3',
          weight: 2,
          opacity: 0.6
        };
      })
      .filter(Boolean);
  };

  if (typeof window === 'undefined') {
    return (
      <Box sx={{ 
        height: '100%', 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'center',
        bgcolor: '#f5f5f5'
      }}>
        <Typography>Loading Airbus Fleet Map...</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ height: '100%', position: 'relative' }}>
      {/* Controls */}
      <Box sx={{ 
        position: 'absolute', 
        top: 10, 
        left: 10, 
        zIndex: 1000, 
        bgcolor: 'white', 
        p: 2, 
        borderRadius: 2, 
        boxShadow: 2,
        minWidth: 200
      }}>
        <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 'bold' }}>
          Airbus Fleet Controls
        </Typography>
        
            <FormControlLabel
          control={<Switch checked={showAircraft} onChange={(e) => setShowAircraft(e.target.checked)} />}
          label="Aircraft"
          sx={{ display: 'block', mb: 0.5 }}
        />
            <FormControlLabel
          control={<Switch checked={showFacilities} onChange={(e) => setShowFacilities(e.target.checked)} />}
          label="Maintenance Facilities"
          sx={{ display: 'block', mb: 0.5 }}
        />
            <FormControlLabel
          control={<Switch checked={showAirports} onChange={(e) => setShowAirports(e.target.checked)} />}
          label="Airports"
          sx={{ display: 'block', mb: 0.5 }}
        />
            <FormControlLabel
          control={<Switch checked={showRoutes} onChange={(e) => setShowRoutes(e.target.checked)} />}
          label="Flight Routes"
          sx={{ display: 'block', mb: 1 }}
        />
            <FormControlLabel
          control={<Switch checked={showZones} onChange={(e) => setShowZones(e.target.checked)} />}
          label="Operational Zones"
          sx={{ display: 'block', mb: 1 }}
        />

        <FormControl fullWidth size="small" sx={{ mb: 1 }}>
          <InputLabel>Aircraft Type</InputLabel>
          <Select
            value={selectedAircraftType}
            onChange={(e) => setSelectedAircraftType(e.target.value)}
            label="Aircraft Type"
          >
            <MenuItem value="all">All Types</MenuItem>
            <MenuItem value="A380-800">A380-800</MenuItem>
            <MenuItem value="A350-1000">A350-1000</MenuItem>
            <MenuItem value="A350-900">A350-900</MenuItem>
            <MenuItem value="A330-900">A330-900</MenuItem>
            <MenuItem value="A330-300">A330-300</MenuItem>
            <MenuItem value="A320neo">A320neo</MenuItem>
            <MenuItem value="A320ceo">A320ceo</MenuItem>
          </Select>
        </FormControl>

        <FormControl fullWidth size="small">
          <InputLabel>Status</InputLabel>
          <Select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            label="Status"
          >
            <MenuItem value="all">All Status</MenuItem>
            <MenuItem value="active">Active</MenuItem>
            <MenuItem value="maintenance">Maintenance</MenuItem>
            <MenuItem value="grounded">Grounded</MenuItem>
            <MenuItem value="scheduled">Scheduled</MenuItem>
          </Select>
        </FormControl>
        </Box>
        
      {/* Legend */}
        <Box sx={{ 
          position: 'absolute', 
        bottom: 10, 
        right: 10, 
          zIndex: 1000,
        bgcolor: 'white', 
        p: 2, 
        borderRadius: 2, 
        boxShadow: 2,
        minWidth: 180
      }}>
        <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 'bold' }}>
          Legend
          </Typography>
          
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
          <Box sx={{ width: 12, height: 12, bgcolor: '#4caf50', borderRadius: '50%', mr: 1 }} />
          <Typography variant="caption">Active (90%+ Health)</Typography>
                </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
          <Box sx={{ width: 12, height: 12, bgcolor: '#ff9800', borderRadius: '50%', mr: 1 }} />
          <Typography variant="caption">Maintenance (80-89% Health)</Typography>
              </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
          <Box sx={{ width: 12, height: 12, bgcolor: '#f44336', borderRadius: '50%', mr: 1 }} />
                          <Typography variant="caption">Grounded (&lt;80% Health)</Typography>
          </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
          <Box sx={{ width: 8, height: 8, bgcolor: '#4caf50', borderRadius: '50%', mr: 1 }} />
          <Typography variant="caption">Major Facility</Typography>
          </Box>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Box sx={{ width: 6, height: 6, bgcolor: '#2196f3', borderRadius: '50%', mr: 1 }} />
          <Typography variant="caption">Regional Facility</Typography>
        </Box>
          </Box>
          
      {/* Map */}
          <MapContainer
        key={`airbus-fleet-map-${mapKey}`}
        center={[30, 0]}
        zoom={2}
        style={{ height: '100%', width: '100%' }}
        ref={setMap}
          >
            <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />

        {/* Operational Zones */}
        {showZones && zones.map((zone) => (
                  <Circle
            key={zone.id}
            center={[zone.lat, zone.lng]}
            radius={zone.radius}
                    pathOptions={{
              color: getZoneColor(zone.operationalEfficiency),
              fillColor: getZoneColor(zone.operationalEfficiency),
              fillOpacity: getZoneOpacity(zone.operationalEfficiency),
              weight: 1
            }}
          >
            <Popup>
              <div style={{ minWidth: 200 }}>
                <h6 style={{ fontWeight: 'bold', marginBottom: 8, margin: 0 }}>
                  {zone.name}
                </h6>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Aircraft:</strong> {zone.aircraftCount}
                </p>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Avg Health:</strong> {zone.avgHealth}%
                </p>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Efficiency:</strong> {zone.operationalEfficiency}%
                </p>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Facilities:</strong> {zone.maintenanceFacilities}
                </p>
                <span style={{ 
                  display: 'inline-block',
                  padding: '4px 8px',
                  backgroundColor: '#e3f2fd',
                  color: '#1976d2',
                          borderRadius: '4px',
                  fontSize: '12px',
                  border: '1px solid #2196f3'
                }}>
                  {zone.maintenanceOpportunity.replace('_', ' ')}
                </span>
                      </div>
                    </Popup>
                  </Circle>
        ))}

        {/* Flight Routes */}
        {showRoutes && getFlightRoutePaths().map((route) => (
              <Polyline
            key={route.id}
            positions={route.path}
            pathOptions={{
              color: route.color,
              weight: route.weight,
              opacity: route.opacity
            }}
              />
            ))}

        {/* Aircraft Markers */}
        {showAircraft && filteredAircraft.map((aircraft) => (
                <Marker
            key={aircraft.id}
            position={[aircraft.lat, aircraft.lng]}
            icon={L.divIcon({
              html: getAircraftIcon(aircraft),
              className: 'custom-aircraft-icon',
              iconSize: [24, 24],
              iconAnchor: [12, 12]
            })}
          >
            <Popup>
              <div style={{ minWidth: 250 }}>
                <h6 style={{ fontWeight: 'bold', marginBottom: 8, margin: 0 }}>
                  {aircraft.registration}
                </h6>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Type:</strong> {aircraft.type}
                </p>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Status:</strong> {aircraft.status}
                </p>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Health:</strong> {aircraft.health}%
                </p>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Location:</strong> {aircraft.location}
                </p>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Flight Hours:</strong> {aircraft.flightHours}
                </p>
                <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                  <span style={{ 
                    display: 'inline-block',
                    padding: '4px 8px',
                    backgroundColor: aircraft.status === 'active' ? '#e8f5e8' : aircraft.status === 'maintenance' ? '#fff3e0' : '#ffebee',
                    color: aircraft.status === 'active' ? '#2e7d32' : aircraft.status === 'maintenance' ? '#f57c00' : '#c62828',
                    borderRadius: '4px',
                    fontSize: '12px',
                    border: `1px solid ${aircraft.status === 'active' ? '#4caf50' : aircraft.status === 'maintenance' ? '#ff9800' : '#f44336'}`
                  }}>
                    {aircraft.status}
                  </span>
                  <span style={{ 
                    display: 'inline-block',
                    padding: '4px 8px',
                    backgroundColor: 'transparent',
                    color: '#666',
                    borderRadius: '4px',
                    fontSize: '12px',
                    border: '1px solid #ddd'
                  }}>
                    {aircraft.health}% Health
                  </span>
                    </div>
                  </div>
                </Popup>
              </Marker>
            ))}

        {/* Maintenance Facility Markers */}
        {showFacilities && filteredFacilities.map((facility) => (
              <Marker
            key={facility.id}
            position={[facility.lat, facility.lng]}
            icon={L.divIcon({
              html: getFacilityIcon(facility),
              className: 'custom-facility-icon',
              iconSize: [getFacilitySize(facility.type), getFacilitySize(facility.type)],
              iconAnchor: [getFacilitySize(facility.type) / 2, getFacilitySize(facility.type) / 2]
            })}
              >
                <Popup>
              <div style={{ minWidth: 200 }}>
                <h6 style={{ fontWeight: 'bold', marginBottom: 8, margin: 0 }}>
                  {facility.name}
                </h6>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Type:</strong> {facility.type}
                </p>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Capacity:</strong> {facility.capacity} aircraft
                </p>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Utilization:</strong> {facility.utilization}%
                </p>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Status:</strong> {facility.status}
                </p>
                      <span style={{ 
                  display: 'inline-block',
                  padding: '4px 8px',
                  backgroundColor: facility.status === 'operational' ? '#e8f5e8' : facility.status === 'high_demand' ? '#fff3e0' : '#ffebee',
                  color: facility.status === 'operational' ? '#2e7d32' : facility.status === 'high_demand' ? '#f57c00' : '#c62828',
                  borderRadius: '4px',
                  fontSize: '12px',
                  border: `1px solid ${facility.status === 'operational' ? '#4caf50' : facility.status === 'high_demand' ? '#ff9800' : '#f44336'}`
                }}>
                  {facility.status.replace('_', ' ')}
                      </span>
                  </div>
                </Popup>
              </Marker>
            ))}

        {/* Airport Markers */}
        {showAirports && airports.map((airport) => (
              <Marker
            key={airport.id}
            position={[airport.lat, airport.lng]}
            icon={L.divIcon({
              html: '🛫',
              className: 'custom-airport-icon',
              iconSize: [20, 20],
              iconAnchor: [10, 10]
            })}
              >
                <Popup>
              <div style={{ minWidth: 200 }}>
                <h6 style={{ fontWeight: 'bold', marginBottom: 8, margin: 0 }}>
                  {airport.name}
                </h6>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Traffic:</strong> {airport.traffic}
                </p>
                <p style={{ margin: '4px 0', fontSize: '14px' }}>
                  <strong>Type:</strong> {airport.type}
                </p>
                <span style={{ 
                  display: 'inline-block',
                  padding: '4px 8px',
                  backgroundColor: airport.traffic === 'high' ? '#e8f5e8' : '#e3f2fd',
                  color: airport.traffic === 'high' ? '#2e7d32' : '#1976d2',
                  borderRadius: '4px',
                        fontSize: '12px', 
                  border: `1px solid ${airport.traffic === 'high' ? '#4caf50' : '#2196f3'}`
                }}>
                  {airport.traffic}
                </span>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>

      <style jsx global>{`
        .custom-aircraft-icon {
          background: transparent !important;
          border: none !important;
        }
        .custom-facility-icon {
          background: transparent !important;
          border: none !important;
        }
        .custom-airport-icon {
          background: transparent !important;
          border: none !important;
        }
      `}</style>
    </Box>
  );
} 